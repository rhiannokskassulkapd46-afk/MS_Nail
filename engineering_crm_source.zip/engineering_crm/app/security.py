from pwdlib import PasswordHash
from fastapi import Request, HTTPException
from sqlmodel import Session
from .models import Employee

password_hash = PasswordHash.recommended()

def hash_password(password: str) -> str:
    return password_hash.hash(password)

def verify_password(password: str, hashed: str) -> bool:
    try:
        return password_hash.verify(password, hashed)
    except Exception:
        return False

def current_user(request: Request, session: Session) -> Employee:
    user_id = request.session.get("user_id")
    if not user_id:
        raise HTTPException(status_code=401, detail="Требуется вход")
    user = session.get(Employee, int(user_id))
    if not user or not user.active:
        request.session.clear()
        raise HTTPException(status_code=401, detail="Учётная запись недоступна")
    return user
