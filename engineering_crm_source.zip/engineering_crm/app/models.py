from datetime import date, datetime
from typing import Optional
from sqlmodel import SQLModel, Field

class Employee(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    full_name: str
    username: str = Field(index=True, unique=True)
    password_hash: str
    role: str = "engineer"  # admin, lead, engineer
    active: bool = True
    created_at: datetime = Field(default_factory=datetime.utcnow)

class Project(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    code: str = Field(index=True, unique=True)
    name: str
    description: str = ""
    lead_id: Optional[int] = Field(default=None, foreign_key="employee.id")
    start_date: Optional[date] = None
    deadline: Optional[date] = None
    status: str = "В разработке"
    created_at: datetime = Field(default_factory=datetime.utcnow)

class Task(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    number: str = Field(index=True, unique=True)
    name: str
    project_id: int = Field(foreign_key="project.id", index=True)
    work_type: str
    executor_id: int = Field(foreign_key="employee.id", index=True)
    author_id: int = Field(foreign_key="employee.id")
    reviewer_id: Optional[int] = Field(default=None, foreign_key="employee.id")
    status: str = "Новое"
    priority: str = "Обычный"
    start_date: date
    deadline: date
    planned_hours: float = 0
    actual_hours: float = 0
    progress: int = 0
    result_note: str = ""
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

class AuditLog(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    actor_id: Optional[int] = Field(default=None, foreign_key="employee.id")
    action: str
    entity_type: str
    entity_id: int
    details: str = ""
    created_at: datetime = Field(default_factory=datetime.utcnow)
