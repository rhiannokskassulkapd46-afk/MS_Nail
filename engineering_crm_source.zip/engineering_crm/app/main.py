import os
from datetime import date, datetime
from typing import Optional

from fastapi import FastAPI, Request, Depends, Form, HTTPException
from fastapi.responses import RedirectResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
from sqlmodel import Session, select

from .database import engine, create_db_and_tables, get_session
from .models import Employee, Project, Task, AuditLog
from .security import hash_password, verify_password, current_user

app = FastAPI(title="Engineering CRM", version="1.0.0")
secret = os.getenv("SECRET_KEY", "INSECURE-CHANGE-ME")
if secret == "INSECURE-CHANGE-ME" or secret == "CHANGE_THIS_TO_A_LONG_RANDOM_SECRET":
    print("WARNING: Set a unique SECRET_KEY in .env before network deployment.")
app.add_middleware(
    SessionMiddleware, secret_key=secret,
    same_site="lax", https_only=os.getenv("COOKIE_SECURE", "false").lower() == "true"
)
app.mount("/static", StaticFiles(directory="app/static"), name="static")
templates = Jinja2Templates(directory="app/templates")

WORK_TYPES = [
    "Разработка нового изделия",
    "Модернизация существующего изделия",
    "Разработка КД и 3D-моделей",
    "Изменение конструкторской документации",
    "Техническое сопровождение производства",
    "Расчет прочности и инженерные расчеты",
    "Подготовка технического задания",
]
STATUSES = ["Новое", "Назначено", "В работе", "На проверке", "На доработке", "Согласовано", "Выполнено", "Приостановлено"]
PRIORITIES = ["Низкий", "Обычный", "Высокий", "Критический"]

@app.on_event("startup")
def startup():
    create_db_and_tables()
    with Session(engine) as session:
        username = os.getenv("ADMIN_USERNAME", "admin")
        if not session.exec(select(Employee).where(Employee.username == username)).first():
            password = os.getenv("ADMIN_PASSWORD", "ChangeMe-Now-123!")
            session.add(Employee(
                full_name=os.getenv("ADMIN_FULL_NAME", "Администратор CRM"),
                username=username, password_hash=hash_password(password), role="admin"
            ))
            session.commit()

def render(request: Request, name: str, context: dict):
    return templates.TemplateResponse(request=request, name=name, context=context)

def user_or_redirect(request: Request, session: Session):
    try:
        return current_user(request, session)
    except HTTPException:
        return None

def log_action(session: Session, actor: Employee, action: str, entity: str, entity_id: int, details: str = ""):
    session.add(AuditLog(actor_id=actor.id, action=action, entity_type=entity, entity_id=entity_id, details=details))
    session.commit()

def require_role(user: Employee, *roles):
    if user.role not in roles:
        raise HTTPException(status_code=403, detail="Недостаточно прав")

@app.get("/health")
def health():
    return {"status": "ok", "service": "engineering-crm"}

@app.get("/", response_class=HTMLResponse)
def home(request: Request, session: Session = Depends(get_session)):
    user = user_or_redirect(request, session)
    if not user:
        return RedirectResponse("/login", status_code=303)
    tasks = session.exec(select(Task)).all()
    projects = session.exec(select(Project)).all()
    employees = session.exec(select(Employee).where(Employee.active == True)).all()
    today = date.today()
    active = [t for t in tasks if t.status not in ("Выполнено", "Приостановлено")]
    overdue = [t for t in active if t.deadline < today]
    completed = [t for t in tasks if t.status == "Выполнено"]
    status_counts = {s: sum(1 for t in tasks if t.status == s) for s in STATUSES}
    load = []
    for e in employees:
        assigned = [t for t in active if t.executor_id == e.id]
        planned = sum(t.planned_hours for t in assigned)
        load.append({"employee": e, "count": len(assigned), "hours": round(planned, 1)})
    recent = sorted(tasks, key=lambda t: t.updated_at, reverse=True)[:8]
    return render(request, "dashboard.html", {
        "user": user, "task_count": len(tasks), "project_count": len(projects),
        "active_count": len(active), "overdue": overdue, "completed_count": len(completed),
        "status_counts": status_counts, "load": load, "recent": recent,
        "employees": {e.id: e for e in employees}, "projects": {p.id: p for p in projects},
        "today": today
    })

@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    return render(request, "login.html", {"request": request, "error": ""})

@app.post("/login")
def login(request: Request, username: str = Form(...), password: str = Form(...), session: Session = Depends(get_session)):
    user = session.exec(select(Employee).where(Employee.username == username)).first()
    if not user or not user.active or not verify_password(password, user.password_hash):
        return render(request, "login.html", {"request": request, "error": "Неверный логин или пароль"})
    request.session.clear()
    request.session["user_id"] = user.id
    return RedirectResponse("/", status_code=303)

@app.post("/logout")
def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/login", status_code=303)

@app.get("/tasks", response_class=HTMLResponse)
def tasks_page(request: Request, status: str = "", project_id: int = 0, session: Session = Depends(get_session)):
    user = user_or_redirect(request, session)
    if not user:
        return RedirectResponse("/login", status_code=303)
    query = select(Task)
    if user.role == "engineer":
        query = query.where(Task.executor_id == user.id)
    if status:
        query = query.where(Task.status == status)
    if project_id:
        query = query.where(Task.project_id == project_id)
    tasks = session.exec(query.order_by(Task.deadline)).all()
    projects = session.exec(select(Project)).all()
    employees = {e.id: e for e in session.exec(select(Employee)).all()}
    project_map = {p.id: p for p in projects}
    return render(request, "tasks.html", {
        "user": user, "tasks": tasks, "projects": projects, "employees": employees,
        "project_map": project_map, "statuses": STATUSES, "selected_status": status,
        "selected_project": project_id
    })

@app.get("/tasks/new", response_class=HTMLResponse)
def new_task_page(request: Request, session: Session = Depends(get_session)):
    user = user_or_redirect(request, session)
    if not user:
        return RedirectResponse("/login", status_code=303)
    require_role(user, "admin", "lead")
    projects = session.exec(select(Project)).all()
    employees = session.exec(select(Employee).where(Employee.active == True)).all()
    return render(request, "task_form.html", {"user": user, "task": None, "projects": projects,
        "employees": employees, "work_types": WORK_TYPES, "statuses": STATUSES, "priorities": PRIORITIES, "error": ""})

@app.post("/tasks/new")
def create_task(request: Request, number: str = Form(...), name: str = Form(...),
    project_id: int = Form(...), work_type: str = Form(...), executor_id: int = Form(...),
    reviewer_id: int = Form(0), status: str = Form("Новое"), priority: str = Form("Обычный"),
    start_date: date = Form(...), deadline: date = Form(...), planned_hours: float = Form(0),
    session: Session = Depends(get_session)):
    user = user_or_redirect(request, session)
    if not user:
        return RedirectResponse("/login", status_code=303)
    require_role(user, "admin", "lead")
    if deadline < start_date or planned_hours < 0 or status not in STATUSES or work_type not in WORK_TYPES:
        raise HTTPException(400, "Проверьте даты, трудоёмкость и справочники")
    if not session.get(Project, project_id) or not session.get(Employee, executor_id):
        raise HTTPException(400, "Выбранный проект или исполнитель не существует")
    task = Task(number=number, name=name, project_id=project_id, work_type=work_type,
        executor_id=executor_id, author_id=user.id, reviewer_id=reviewer_id or None,
        status=status, priority=priority, start_date=start_date, deadline=deadline,
        planned_hours=planned_hours)
    session.add(task)
    session.commit()
    session.refresh(task)
    log_action(session, user, "Создано задание", "Task", task.id, number)
    return RedirectResponse("/tasks", status_code=303)

@app.post("/tasks/{task_id}/update")
def update_task(task_id: int, request: Request, status: str = Form(...),
    progress: int = Form(...), actual_hours: float = Form(0), result_note: str = Form(""),
    session: Session = Depends(get_session)):
    user = user_or_redirect(request, session)
    if not user:
        return RedirectResponse("/login", status_code=303)
    task = session.get(Task, task_id)
    if not task:
        raise HTTPException(404, "Задание не найдено")
    if user.role == "engineer" and task.executor_id != user.id:
        raise HTTPException(403, "Можно изменять только назначенные вам задания")
    require_role(user, "admin", "lead", "engineer")
    if status not in STATUSES or not 0 <= progress <= 100 or actual_hours < 0:
        raise HTTPException(400, "Проверьте статус, прогресс и часы")
    task.status, task.progress = status, progress
    task.actual_hours, task.result_note = actual_hours, result_note
    if status == "Выполнено":
        task.progress = 100
    task.updated_at = datetime.utcnow()
    session.add(task)
    session.commit()
    log_action(session, user, "Обновлено задание", "Task", task.id, f"{task.number}: {status}, {progress}%")
    return RedirectResponse("/tasks", status_code=303)

@app.get("/projects", response_class=HTMLResponse)
def projects_page(request: Request, session: Session = Depends(get_session)):
    user = user_or_redirect(request, session)
    if not user:
        return RedirectResponse("/login", status_code=303)
    projects = session.exec(select(Project).order_by(Project.code)).all()
    employees = {e.id: e for e in session.exec(select(Employee)).all()}
    return render(request, "projects.html", {"user": user, "projects": projects, "employees": employees})

@app.get("/projects/new", response_class=HTMLResponse)
def new_project_page(request: Request, session: Session = Depends(get_session)):
    user = user_or_redirect(request, session)
    if not user:
        return RedirectResponse("/login", status_code=303)
    require_role(user, "admin", "lead")
    employees = session.exec(select(Employee).where(Employee.active == True)).all()
    return render(request, "project_form.html", {"user": user, "employees": employees})

@app.post("/projects/new")
def create_project(request: Request, code: str = Form(...), name: str = Form(...),
    description: str = Form(""), lead_id: int = Form(0),
    start_date: Optional[date] = Form(None), deadline: Optional[date] = Form(None),
    session: Session = Depends(get_session)):
    user = user_or_redirect(request, session)
    if not user:
        return RedirectResponse("/login", status_code=303)
    require_role(user, "admin", "lead")
    if start_date and deadline and deadline < start_date:
        raise HTTPException(400, "Срок завершения раньше даты начала")
    project = Project(code=code, name=name, description=description,
        lead_id=lead_id or None, start_date=start_date, deadline=deadline)
    session.add(project)
    session.commit()
    session.refresh(project)
    log_action(session, user, "Создан проект", "Project", project.id, code)
    return RedirectResponse("/projects", status_code=303)

@app.get("/employees", response_class=HTMLResponse)
def employees_page(request: Request, session: Session = Depends(get_session)):
    user = user_or_redirect(request, session)
    if not user:
        return RedirectResponse("/login", status_code=303)
    require_role(user, "admin", "lead")
    employees = session.exec(select(Employee).order_by(Employee.full_name)).all()
    return render(request, "employees.html", {"user": user, "employees": employees})

@app.post("/employees/new")
def create_employee(request: Request, full_name: str = Form(...), username: str = Form(...),
    password: str = Form(...), role: str = Form(...), session: Session = Depends(get_session)):
    user = user_or_redirect(request, session)
    if not user:
        return RedirectResponse("/login", status_code=303)
    require_role(user, "admin")
    if role not in ("admin", "lead", "engineer") or len(password) < 12:
        raise HTTPException(400, "Недопустимая роль или пароль короче 12 символов")
    if session.exec(select(Employee).where(Employee.username == username)).first():
        raise HTTPException(400, "Такой логин уже существует")
    session.add(Employee(full_name=full_name, username=username,
        password_hash=hash_password(password), role=role))
    session.commit()
    return RedirectResponse("/employees", status_code=303)

@app.get("/audit", response_class=HTMLResponse)
def audit_page(request: Request, session: Session = Depends(get_session)):
    user = user_or_redirect(request, session)
    if not user:
        return RedirectResponse("/login", status_code=303)
    require_role(user, "admin", "lead")
    logs = session.exec(select(AuditLog).order_by(AuditLog.created_at.desc()).limit(100)).all()
    actors = {e.id: e for e in session.exec(select(Employee)).all()}
    return render(request, "audit.html", {"user": user, "logs": logs, "actors": actors})
