import sqlite3
from pathlib import Path
from datetime import date, datetime, timedelta
import pandas as pd
import streamlit as st

DB = Path(__file__).with_name("kb_crm.db")
STATUSES = ["Новая", "Запланирована", "В работе", "На проверке", "Приостановлена", "Завершена", "Отменена"]
TYPES = ["Разработка нового изделия", "Модернизация изделия", "Разработка КД", "3D-моделирование", "Изменение КД", "Техническое сопровождение производства", "Расчет прочности", "Инженерный расчет", "Подготовка технического задания", "Прочее"]
PRIORITIES = ["Низкий", "Обычный", "Высокий", "Критический"]

def conn():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    return c

def init():
    with conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS employees(id INTEGER PRIMARY KEY, name TEXT NOT NULL, role TEXT NOT NULL, active INTEGER DEFAULT 1);
        CREATE TABLE IF NOT EXISTS projects(id INTEGER PRIMARY KEY, code TEXT, name TEXT NOT NULL, customer TEXT, manager INTEGER, start TEXT, due TEXT, status TEXT, description TEXT, FOREIGN KEY(manager) REFERENCES employees(id));
        CREATE TABLE IF NOT EXISTS tasks(id INTEGER PRIMARY KEY, project INTEGER, title TEXT NOT NULL, kind TEXT, assignee INTEGER, reviewer INTEGER, priority TEXT, status TEXT, start TEXT, due TEXT, plan REAL DEFAULT 0, fact REAL DEFAULT 0, progress INTEGER DEFAULT 0, description TEXT, result TEXT, updated TEXT, FOREIGN KEY(project) REFERENCES projects(id), FOREIGN KEY(assignee) REFERENCES employees(id), FOREIGN KEY(reviewer) REFERENCES employees(id));
        CREATE TABLE IF NOT EXISTS log(id INTEGER PRIMARY KEY, entity TEXT, record_id INTEGER, action TEXT, details TEXT, created TEXT);
        """)

def df(sql, args=()):
    with conn() as c:
        return pd.read_sql_query(sql, c, params=args)

def audit(c, entity, rid, action, details=""):
    c.execute("INSERT INTO log(entity,record_id,action,details,created) VALUES(?,?,?,?,?)",
              (entity,rid,action,details,datetime.now().isoformat(timespec="seconds")))

def employee_options():
    d=df("SELECT id,name FROM employees WHERE active=1 ORDER BY name")
    return [(None,"Не назначен")] + [(int(r.id),r.name) for r in d.itertuples()]

def project_options():
    d=df("SELECT id,name FROM projects ORDER BY name")
    return [(None,"Без проекта")] + [(int(r.id),r.name) for r in d.itertuples()]

init()
st.set_page_config(page_title="CRM конструкторского отдела", page_icon="⚙️", layout="wide")
st.title("⚙️ CRM конструкторского отдела")
st.caption("Локальная версия на Python + Streamlit + SQLite. Данные находятся в файле kb_crm.db.")

with st.sidebar:
    page=st.radio("Раздел",["Дашборд","Задачи","Проекты","Сотрудники","Отчеты","Журнал"])
    st.divider()
    st.caption("Резервная копия: копируйте kb_crm.db после закрытия приложения.")

if page=="Сотрудники":
    st.subheader("Сотрудники")
    with st.expander("Добавить сотрудника"):
        with st.form("emp"):
            name=st.text_input("ФИО")
            role=st.selectbox("Должность",["Начальник отдела","Ведущий конструктор","Конструктор"])
            if st.form_submit_button("Добавить"):
                if name.strip():
                    with conn() as c:
                        cur=c.execute("INSERT INTO employees(name,role) VALUES(?,?)",(name.strip(),role))
                        audit(c,"Сотрудник",cur.lastrowid,"Создание",name)
                    st.rerun()
                else: st.error("Введите ФИО.")
    d=df("SELECT id,name AS 'ФИО',role AS 'Должность',CASE active WHEN 1 THEN 'Да' ELSE 'Нет' END AS 'Активен' FROM employees ORDER BY name")
    st.dataframe(d,use_container_width=True,hide_index=True)
    if not d.empty:
        eid=st.selectbox("Сотрудник",d.id.tolist(),format_func=lambda x:f"#{x} — {d.loc[d.id==x,'ФИО'].iloc[0]}")
        if st.button("Изменить активность"):
            with conn() as c:
                c.execute("UPDATE employees SET active=1-active WHERE id=?",(eid,))
                audit(c,"Сотрудник",eid,"Изменение активности")
            st.rerun()

elif page=="Проекты":
    st.subheader("Проекты")
    with st.expander("Создать проект"):
        with st.form("proj",clear_on_submit=True):
            code=st.text_input("Шифр проекта")
            name=st.text_input("Наименование")
            customer=st.text_input("Заказчик / подразделение")
            manager=st.selectbox("Ответственный",employee_options(),format_func=lambda x:x[1])
            a,b=st.columns(2)
            start=a.date_input("Дата начала",date.today())
            due=b.date_input("Срок завершения",date.today()+timedelta(days=30))
            status=st.selectbox("Статус",["Инициация","В работе","На согласовании","Приостановлен","Завершен","Отменен"])
            desc=st.text_area("Описание")
            if st.form_submit_button("Сохранить"):
                if name.strip():
                    with conn() as c:
                        cur=c.execute("INSERT INTO projects(code,name,customer,manager,start,due,status,description) VALUES(?,?,?,?,?,?,?,?)",
                                      (code,name.strip(),customer,manager[0],start.isoformat(),due.isoformat(),status,desc))
                        audit(c,"Проект",cur.lastrowid,"Создание",name)
                    st.rerun()
                else: st.error("Введите наименование проекта.")
    st.dataframe(df("""SELECT p.id,p.code AS 'Шифр',p.name AS 'Проект',p.customer AS 'Заказчик',e.name AS 'Ответственный',p.start AS 'Начало',p.due AS 'Срок',p.status AS 'Статус' FROM projects p LEFT JOIN employees e ON e.id=p.manager ORDER BY p.id DESC"""),use_container_width=True,hide_index=True)

elif page=="Задачи":
    st.subheader("Задачи и поручения")
    with st.expander("Создать задачу"):
        with st.form("task",clear_on_submit=True):
            title=st.text_input("Наименование задачи")
            a,b=st.columns(2)
            project=a.selectbox("Проект",project_options(),format_func=lambda x:x[1])
            kind=b.selectbox("Направление работ",TYPES)
            c,d=st.columns(2)
            assignee=c.selectbox("Исполнитель",employee_options(),format_func=lambda x:x[1])
            reviewer=d.selectbox("Проверяющий / ведущий",employee_options(),format_func=lambda x:x[1])
            e,f,g=st.columns(3)
            priority=e.selectbox("Приоритет",PRIORITIES)
            status=f.selectbox("Статус",STATUSES)
            progress=g.number_input("Готовность, %",0,100,0)
            h,i=st.columns(2)
            start=h.date_input("Дата начала",date.today())
            due=i.date_input("Срок",date.today()+timedelta(days=7))
            j,k=st.columns(2)
            plan=j.number_input("Плановые часы",min_value=0.0,step=1.0)
            fact=k.number_input("Фактические часы",min_value=0.0,step=1.0)
            desc=st.text_area("Техническое задание / описание")
            if st.form_submit_button("Создать"):
                if title.strip():
                    with conn() as c:
                        cur=c.execute("""INSERT INTO tasks(project,title,kind,assignee,reviewer,priority,status,start,due,plan,fact,progress,description,updated)
                        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",(project[0],title.strip(),kind,assignee[0],reviewer[0],priority,status,start.isoformat(),due.isoformat(),plan,fact,int(progress),desc,datetime.now().isoformat(timespec="seconds")))
                        audit(c,"Задача",cur.lastrowid,"Создание",title)
                    st.rerun()
                else: st.error("Введите наименование задачи.")
    d=df("""SELECT t.id,t.title AS 'Задача',p.name AS 'Проект',t.kind AS 'Направление',e.name AS 'Исполнитель',r.name AS 'Проверяющий',t.priority AS 'Приоритет',t.status AS 'Статус',t.start AS 'Начало',t.due AS 'Срок',t.progress AS 'Готовность, %',t.plan AS 'План, ч',t.fact AS 'Факт, ч',t.description AS 'Описание',t.result AS 'Комментарий'
    FROM tasks t LEFT JOIN projects p ON p.id=t.project LEFT JOIN employees e ON e.id=t.assignee LEFT JOIN employees r ON r.id=t.reviewer ORDER BY t.due""")
    if not d.empty:
        x,y,z=st.columns(3)
        statuses=x.multiselect("Статус",STATUSES,default=STATUSES)
        people=["Все"]+sorted(d["Исполнитель"].dropna().unique().tolist())
        person=y.selectbox("Исполнитель",people)
        projects=["Все"]+sorted(d["Проект"].dropna().unique().tolist())
        proj=z.selectbox("Проект",projects)
        view=d[d["Статус"].isin(statuses)]
        if person!="Все": view=view[view["Исполнитель"]==person]
        if proj!="Все": view=view[view["Проект"]==proj]
        st.dataframe(view,use_container_width=True,hide_index=True)
        st.subheader("Обновить задачу")
        tid=st.selectbox("Выберите задачу",d.id.tolist(),format_func=lambda n:f"#{n} — {d.loc[d.id==n,'Задача'].iloc[0]}")
        old=df("SELECT * FROM tasks WHERE id=?",(tid,)).iloc[0]
        with st.form("upd"):
            a,b,c=st.columns(3)
            ns=a.selectbox("Статус",STATUSES,index=STATUSES.index(old.status))
            np=b.number_input("Готовность, %",0,100,int(old.progress))
            nf=c.number_input("Фактические часы",min_value=0.0,value=float(old.fact),step=1.0)
            note=st.text_area("Комментарий / результат",old.result or "")
            if st.form_submit_button("Сохранить изменения"):
                with conn() as c:
                    c.execute("UPDATE tasks SET status=?,progress=?,fact=?,result=?,updated=? WHERE id=?",(ns,int(np),nf,note,datetime.now().isoformat(timespec="seconds"),tid))
                    audit(c,"Задача",tid,"Обновление",f"{ns}; {np}%; факт {nf} ч")
                st.rerun()
    else: st.info("Задач пока нет.")

elif page=="Дашборд":
    t=df("SELECT * FROM tasks")
    p=df("SELECT * FROM projects")
    e=df("SELECT * FROM employees WHERE active=1")
    today=date.today().isoformat()
    open_t=t[~t.status.isin(["Завершена","Отменена"])] if not t.empty else t
    overdue=open_t[open_t.due.fillna("").lt(today)] if not open_t.empty else open_t
    a,b,c,d=st.columns(4)
    a.metric("Проекты",len(p)); b.metric("Активные задачи",len(open_t)); c.metric("Просроченные",len(overdue)); d.metric("Сотрудники",len(e))
    if not t.empty:
        st.subheader("Распределение задач по статусам")
        st.bar_chart(t.groupby("status").size())
        st.subheader("Ближайшие сроки")
        upcoming=t[(t.due.fillna("")>=today)&(t.status!="Завершена")].sort_values("due").head(12)
        st.dataframe(upcoming[["title","kind","status","due","progress","plan","fact"]],use_container_width=True,hide_index=True)
    else: st.info("Добавьте сотрудников, проекты и задачи.")

elif page=="Отчеты":
    st.subheader("Отчеты")
    d=df("""SELECT t.id,t.title AS 'Задача',p.name AS 'Проект',e.name AS 'Исполнитель',t.kind AS 'Направление',t.status AS 'Статус',t.due AS 'Срок',t.progress AS 'Готовность, %',t.plan AS 'План, ч',t.fact AS 'Факт, ч'
    FROM tasks t LEFT JOIN projects p ON p.id=t.project LEFT JOIN employees e ON e.id=t.assignee""")
    if not d.empty:
        open_d=d[~d["Статус"].isin(["Завершена","Отменена"])]
        load=open_d.groupby("Исполнитель",dropna=False)["План, ч"].sum().fillna(0)
        st.markdown("**Плановая загрузка по исполнителям (открытые задачи)**")
        st.bar_chart(load)
        st.markdown("**Сводка по проектам**")
        summary=d.groupby("Проект",dropna=False).agg(Задач=("id","count"),Средняя_готовность=("Готовность, %","mean"),План_ч=("План, ч","sum"),Факт_ч=("Факт, ч","sum")).reset_index()
        st.dataframe(summary,use_container_width=True,hide_index=True)
        st.download_button("Скачать реестр задач CSV",d.to_csv(index=False).encode("utf-8-sig"),"zadachi_kb.csv","text/csv")
    else: st.info("Нет данных для отчета.")

else:
    st.subheader("Журнал действий")
    st.dataframe(df("SELECT created AS 'Дата',entity AS 'Раздел',record_id AS 'ID',action AS 'Действие',details AS 'Подробности' FROM log ORDER BY id DESC LIMIT 500"),use_container_width=True,hide_index=True)
