@echo off
chcp 65001 >nul
cd /d "%~dp0"
py -m pip install -r requirements.txt
if errorlevel 1 (
  echo Ошибка установки библиотек. Проверьте Python и подключение к интернету.
  pause
  exit /b 1
)
py -m streamlit run app.py
pause
